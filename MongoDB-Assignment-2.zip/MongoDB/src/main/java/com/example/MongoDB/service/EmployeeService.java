package com.example.MongoDB.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MongoDB.entity.Employee;
import com.example.MongoDB.mathUtils.MathCalculation;
import com.example.MongoDB.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private CustomSeqService customSeqService;

	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		int empid = customSeqService.getNextSeq("empSeq");
		emp.setId(empid);
		employeeRepository.save(emp);
		
	}

	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		
		return employeeRepository.findAll();
	}
	public Employee getEmployee(int id) {
		Optional<Employee> emp = employeeRepository.findById(id);
		return emp.get();
 	}
	public Employee getEmployeeByName(String name) {
		Optional<Employee> emp= employeeRepository.findByName(name);
		return emp.get();
	}
	public int getEmployeeCountByName(String name) {
		int count = employeeRepository.getEmployeeCountByName(name);
		return count;
	}


	public String updateEmployee(int empId) {
		// TODO Auto-generated method stub
		return null;
	}
	

	public String deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public int add(int a, int b) {
		MathCalculation obj = new MathCalculation();
		return obj.add(a, b);
	}

	public int addAndDouble(int no1, int no2) {
		// TODO Auto-generated method stub
		MathCalculation obj = new MathCalculation();
		int addition =  obj.add(no1, no2);
		return addition*2;
		
	}

	

}
