package com.example.MongoDB.mathUtils;

public class MathCalculation {

	public int add(int a, int b) {
		
		return a+b;
	}
	public int addAndDouble(int a, int b) {
		return add(a,b)*2;
	}
}
