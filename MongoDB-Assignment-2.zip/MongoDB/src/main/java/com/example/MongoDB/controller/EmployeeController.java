package com.example.MongoDB.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.MongoDB.entity.Employee;
import com.example.MongoDB.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@PostMapping("/employee")
	public String addEmployee(@RequestBody Employee emp) {
		employeeService.addEmployee(emp);
		return "Employee Added Successfully";
		
	}
	@GetMapping("/employee")
	public  List<Employee> getAllEmployee() {
		List<Employee> lstList = employeeService.getAllEmployee();
		return lstList;
		
	}
	@GetMapping("/employee/{id}")
	public Employee getEmployee(@PathVariable int id) {
		Employee emp= employeeService.getEmployee(id);
		return emp;
	}
	@GetMapping("/employee/byName/{name}")
	public Employee getEmployeeByName(@PathVariable String name) {
		Employee emp= employeeService.getEmployeeByName(name);
		return emp;
	}
	@GetMapping("/employee/countByName/{name}")
	public int getEmployeeCountByName(@PathVariable String name) {
		int count = employeeService.getEmployeeCountByName(name);
		return count;
	}
	@PutMapping("employee/{id}")
	public String updateEmployee(@PathVariable("id") int empId) {
		String message = employeeService.updateEmployee(empId);
		return message;
	}
	@DeleteMapping("/employee/{id}")
	public String deleteEmployee(@PathVariable("id") int empId) {
		String message = employeeService.deleteEmployee(empId);
		return message;
	}
	@GetMapping("/add/{no1}/{no2}")
	public int add(@PathVariable int no1, @PathVariable int no2) {
		int result = employeeService.add(no1, no2);
		return result;
	}
	@GetMapping("/addAndDouble/{no1}/{no2}")
	public int addAndDouble(@PathVariable int no1, @PathVariable int no2) {
		int result = employeeService.addAndDouble(no1,no2);
		return result;
	}

}
