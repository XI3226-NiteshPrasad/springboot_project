package com.example.MongoDB.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.example.MongoDB.entity.Employee;


public interface EmployeeRepository extends MongoRepository<Employee, Integer>{

//	@Query("new com.example.MongoDB.dto.EmployeeDto(id,name) from Employee")
//	Employee findByName(String name);
	
	Optional<Employee> findByName(String name);
	@Query(value="{name: ?0}",count = true)
	Integer getEmployeeCountByName(String name);
	
}
