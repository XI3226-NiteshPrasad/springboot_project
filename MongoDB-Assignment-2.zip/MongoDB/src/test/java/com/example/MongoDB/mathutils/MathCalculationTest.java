package com.example.MongoDB.mathutils;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.MongoDB.mathUtils.MathCalculation;

@SpringBootTest
public class MathCalculationTest {
	
	@Test
	public void testAdd() {
		
		MathCalculation mathCalculation = new MathCalculation();
		
		int result = mathCalculation.add(0, 0);
		assertEquals(0, result);
		
		result = mathCalculation.add(2, 2);
		assertEquals(4, result);
		
		result = mathCalculation.add(1, -1);
		assertEquals(0, result);
		
		
	}
	@Test
	public void testaddAndDouble() {
		
		MathCalculation mathCalculation = new MathCalculation();
		
		int result = mathCalculation.addAndDouble(0, 0);
		assertEquals(0, result);
		
		result = mathCalculation.addAndDouble(2, 2);
		assertEquals(8, result);
		
		result = mathCalculation.addAndDouble(1, -1);
		assertEquals(0, result);
		
		
	}
}
