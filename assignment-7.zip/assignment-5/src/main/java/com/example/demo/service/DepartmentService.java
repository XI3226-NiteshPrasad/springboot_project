package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import com.example.demo.repository.DepartmentRepository;

@Service
public class DepartmentService {
	
	@Autowired
	DepartmentRepository departmentRepository;

	public Department getSingleDepartment(int deptId) {
		// TODO Auto-generated method stub
		Optional<Department> optDept = departmentRepository.findById(deptId);
		
		return optDept.isPresent()? optDept.get() : null;
	}

	public String updateEmployee(Department dept, int deptId) {
		// TODO Auto-generated method stub
		return null;
	}

	public String deleteDepartment(int deptId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Department> getAllDepartment() {
		// TODO Auto-generated method stub
		return departmentRepository.findAll();
		
	}

	public String addDepartment(Department department) {
		// TODO Auto-generated method stub
		departmentRepository.save(department);
		return null;
	}
}
