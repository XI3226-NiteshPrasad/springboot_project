package com.example.demo.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;

@Service
public class EmployeeRepository {

	List<Employee> empList = new ArrayList<>();
	
	public List<Employee> save(Employee employee) {
		empList.add(employee);
		return empList;
	}
	public List<Employee> getAllEmployees(){
		return empList;
	}
	public Employee getSingleEmployee(int empId) {
		Optional<Employee> optEmp = empList.stream().filter(emp -> emp.getId()==empId).findFirst();
		if(optEmp.isPresent()) {
			return optEmp.get();
		}
		else {
			return null;
		}
		
	}
	public void updateEmployee(Employee emp, int empId) {
		empList.forEach(e -> {
			if(e.getId() == empId) {
				e.setEmail(emp.getEmail());
				e.setName(emp.getName());
			}
		});
		
	}
}

