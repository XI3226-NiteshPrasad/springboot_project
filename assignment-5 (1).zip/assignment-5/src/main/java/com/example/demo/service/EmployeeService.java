package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {

	
	@Autowired
	EmployeeRepository employeeRepository;
	
	public String addEmployee(@RequestBody Employee employee) {
		employeeRepository.save(employee);
		System.out.println(employeeRepository);
		return "Employee Added Successfully";
	}
	public List<Employee> getAllEmployee(){
		List<Employee> empList = employeeRepository.getAllEmployees();
		return empList;
	}
	public Employee getSingleEmployee(int empId) {
		Employee emp = employeeRepository.getSingleEmployee(empId);
		return emp;
	}
	public String updateEmployee(Employee emp, int empId) {
		Employee emp1 = employeeRepository.getSingleEmployee(empId);
		if(emp1 != null) {
			employeeRepository.updateEmployee( emp, empId);
			return "Employee updated successfully";
		}

		return null;
	}
}
