package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {

//	request -> controller -> service -> repository(entity)
	
	//1) add employee into system
	//2) get all the employee
	//3) get one employee
	//4) update specific employee
	//5) delete specific employee
	
	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	//localhost:8080/api/employee
	@PostMapping("/employee")
	public String addEmployee(@RequestBody Employee employee) {
		String message = employeeService.addEmployee(employee);
		System.out.println(employeeRepository);
		return message;
	}
	//localhost:8080/api/employee
	@GetMapping("/employee")
	public List<Employee> getAllEmployees(){
		List<Employee> lstEmp = employeeService.getAllEmployee();
		return lstEmp;
	}
	
	//localhost:8080/api/employee/{id}
	@GetMapping("/employee/{id}")
	public Employee getSingleEmployee(@PathVariable("id") int empId) {
		Employee emp = employeeService.getSingleEmployee(empId);
		return emp;
	}
	//localhost:8080/api/employee/1
	@PutMapping("employee/{id}")
	public String updateEmployee(@RequestBody Employee emp, @PathVariable("id") int empId) {
		String message = employeeService.updateEmployee(emp, empId);
		return message;
	}
}
