package Task1;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Operations {

	
	public static void main(String args[]) {
		
		List<Employee> list = new ArrayList<>();
		list.add(new Employee(1,"Aman",30000));
		list.add(new Employee(2,"Garima",60000));
		list.add(new Employee(3,"Shalini",34000));
		list.add(new Employee(4,"Roushan",80000));
		list.add(new Employee(5,"Nitesh",70000));
		list.add(new Employee(6,"Ansh",40000));
		
//		for (int i = 0 ; i < list.size(); i++) {
//			Employee e = list.get(i);
//			if(e.getSalary() > 50000) {
//				System.out.println(e.getEmpname());
//			}
//		}
		
		//JAVA 8 stream API
		//predicate
		//consumer
		//method refrence
		
		list.stream().filter(e -> e.getSalary()>50000).forEach(e -> System.out.println(e.toString()));
		
		Integer sum = list.stream().filter(Employee::sumSalary).collect(Collectors.summingInt(e->e.getSalary()));
		System.out.println("The sum of salary of emloyee whose name start with a is " +sum);
	}
}
