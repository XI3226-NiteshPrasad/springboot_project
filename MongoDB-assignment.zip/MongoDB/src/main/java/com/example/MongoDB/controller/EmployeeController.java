package com.example.MongoDB.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.MongoDB.entity.Employee;
import com.example.MongoDB.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@PostMapping("/employee")
	public String addEmployee(@RequestBody Employee emp) {
		employeeService.addEmployee(emp);
		return "Employee Added Successfully";
		
	}
	@GetMapping("/employee")
	public  List<Employee> getAllEmployee() {
		List<Employee> lstList = employeeService.getAllEmployee();
		return lstList;
		
	}
	

}
