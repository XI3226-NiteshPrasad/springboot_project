package com.example.MongoDB.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MongoDB.entity.Employee;
import com.example.MongoDB.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private CustomSeqService customSeqService;

	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		int empid = customSeqService.getNextSeq("empSeq");
		emp.setId(empid);
		employeeRepository.save(emp);
		
	}

	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		
		return employeeRepository.findAll();
	}
	

}
