package even;


import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class EvenList {

	public static void main(String[] args) {
		var list = new ArrayList<Integer>();
		list.add(2);
		list.add(4);
		list.add(7);
		
		Predicate<Integer> p = (var t)-> t%2 == 0;
		
		var numberList = list.stream().filter(p).collect(Collectors.toList());
		System.out.println(numberList);
	}
	
}
