package files;

import java.util.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileOperations {
		
	public static void main(String[] args) {
		
		try {
			
			String p = "C:\\Users\\Nitesh.Prasad\\OneDrive - Xebia Nederland B.V\\Bureaublad\\abc\\dummy.txt";
			String s = Files.readString(Paths.get(p)); 
			System.out.println(s);
			
			Path file = Paths.get(p);
			long count = Files.lines(file).count();
					
			System.out.println("Total lines"+count);
			
			
			
		}
			
		catch(IOException e){
			e.printStackTrace();
		}  
	}

}
